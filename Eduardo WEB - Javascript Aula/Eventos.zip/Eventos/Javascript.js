// JavaScript Document
function bemvindo()
{alert("bem vindo")
	}
function botao()
{ alert("mensagem do Botão")
	}
function link()
{alert("mensagem do Link")}
function paragrafo()
{alert("mensagem do Paragrafo")}
function formsub()
{alert("mensagem do formulario do onsubmit")}
function mouseover()
{document.btn.value ="muda o nome do botao";
	}
function mouseout()
{document.btn.value="cima em cima cara,nao faz isso!!"}
function focomatri()
{}